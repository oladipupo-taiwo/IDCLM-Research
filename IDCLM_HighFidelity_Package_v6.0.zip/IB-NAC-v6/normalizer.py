"""Deterministic policy canonicalization used by IDCLM v4.0."""
from __future__ import annotations
import json
from typing import Any, Mapping

VOLATILE_FIELDS = {"timestamp","record_id","created_at","updated_at","deployment_id","runtime_id"}
SEMANTIC_FIELDS = (
    "policy_id","intent_id","subject","resource","decision","src_ip","dst_ip",
    "protocol","ios_command","enforcement_point","status","version_id","version"
)

def _normalize_value(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _normalize_value(v) for k,v in sorted(value.items(), key=lambda kv:str(kv[0]))
                if str(k) not in VOLATILE_FIELDS}
    if isinstance(value, list):
        return [_normalize_value(v) for v in value]
    return value

def normalize_policy(policy: Mapping[str,Any]) -> dict[str,Any]:
    selected = {k: policy[k] for k in SEMANTIC_FIELDS if k in policy}
    return _normalize_value(selected if selected else dict(policy))

def canonical_json(policy: Mapping[str,Any]) -> str:
    return json.dumps(normalize_policy(policy), sort_keys=True, separators=(",",":"), ensure_ascii=False)

def canonical_bytes(policy: Mapping[str,Any]) -> bytes:
    return canonical_json(policy).encode("utf-8")
