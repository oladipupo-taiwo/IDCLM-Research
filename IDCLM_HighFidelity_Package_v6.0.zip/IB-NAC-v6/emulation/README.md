# Optional high-fidelity network-emulation extension

The core v5 package is executable without a network emulator. This directory
contains the integration contract for a higher-fidelity validation stage.

## Recommended environment

- Mininet
- Open vSwitch
- an SDN controller reachable through OpenFlow/REST
- Linux host networking

The goal is to replace the Packet Tracer-only context with an experiment in
which an actual virtual switch/controller enforcement state is changed, IDCLM
observes the state, detects the deviation, and restores the trusted state.

## Required measurements

Record at minimum:

1. policy deployment time;
2. unauthorized change time;
3. telemetry acquisition time;
4. cryptographic verification time;
5. detection latency;
6. rollback time;
7. revalidation time;
8. end-to-end remediation latency;
9. CPU and RAM overhead;
10. control-plane traffic overhead.

The manuscript must label these results as emulation/testbed evidence, not as
physical-device evidence.

## Suggested topology

client groups (Finance / IT / Guest)
        |
     OVS switches
        |
   SDN controller
        |
      IDCLM

Attack procedure:

1. deploy the authorized policy;
2. confirm compliant state;
3. mutate an enforcement rule outside the trusted workflow;
4. capture telemetry;
5. run IDCLM verification;
6. trigger rollback;
7. verify the restored enforcement state;
8. repeat for each attack class.

This directory intentionally does not fake a Mininet result on systems where
Mininet is not installed. The experiment must be run in the actual emulator
environment and the raw measurements copied into `results/`.
