"""IDCLM v5.0 upgraded scientific-evidence suite.

This module extends the v4.0 reproducibility package with:
- hypothesis-driven security evaluation;
- 12 attack classes plus benign canonicalization cases;
- baseline and ablation comparisons;
- repeated timing measurements with 95% CIs and p95/p99;
- rollback and end-to-end software/emulation latency;
- resource-overhead measurements when psutil is available;
- larger scalability workloads;
- sequential-vs-Merkle proof benchmarking;
- heterogeneous policy generation;
- machine-readable raw/aggregate outputs.

Important scope:
The package can execute software-level and emulated experiments locally. It does
NOT by itself establish evidence on physical network devices, production SDN
controllers, TPM/HSM hardware, or distributed consensus. The optional
emulation adapter is provided separately and must be run in an environment
that actually contains the required networking stack.
"""
from __future__ import annotations

import argparse, copy, csv, json, math, os, random, statistics, time, tracemalloc
from pathlib import Path
from typing import Any, Callable

import numpy as np

from ledger import append, load as load_ledger, save as save_ledger, verify_chain, policy_hash
from normalizer import canonical_bytes
from security import Signer
from verifier import trusted_policy_map, verify_policy_set, verify_policy
from rollback.manager import RollbackManager
from extensions.hrot import SoftwareRootOfTrust
from extensions.merkle_tree import merkle_root, build_proof, verify_proof

BASE = Path(__file__).resolve().parent
RESULTS = BASE / "results"
RESULTS.mkdir(exist_ok=True)
POLICIES_FILE = BASE / "compiled_policies.json"
LEDGER_FILE = BASE / "audit_ledger.json"

ATTACK_TYPES = [
    "decision_flip", "source_address_change", "destination_change",
    "protocol_change", "enforcement_command_change", "enforcement_point_change",
    "stale_replay", "forged_signature", "version_manipulation",
    "hrot_tag_tamper", "ledger_record_tamper", "partial_deployment"
]
BENIGN_TYPES = ["timestamp_change", "key_reordering", "runtime_metadata_addition"]

def load_json(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def save_json(p, o): Path(p).write_text(json.dumps(o, indent=2, ensure_ascii=False), encoding="utf-8")
def load_policies(): return load_json(POLICIES_FILE)
def save_policies(p): save_json(POLICIES_FILE, p)
def time_call(fn):
    t = time.perf_counter_ns()
    r = fn()
    return (time.perf_counter_ns() - t) / 1e6, r

def ci95(values):
    x = np.asarray(values, dtype=float)
    if len(x) < 2: return [float(x.mean()) if len(x) else 0.0, float(x.mean()) if len(x) else 0.0]
    m, s = float(x.mean()), float(x.std(ddof=1))
    # 1.96 is a conservative large-sample approximation; raw observations are retained.
    return [m - 1.96 * s / math.sqrt(len(x)), m + 1.96 * s / math.sqrt(len(x))]

def summary(values):
    x = np.asarray(values, dtype=float)
    return {
        "n": int(len(x)),
        "mean": float(x.mean()) if len(x) else 0.0,
        "median": float(np.median(x)) if len(x) else 0.0,
        "stdev": float(x.std(ddof=1)) if len(x) > 1 else 0.0,
        "p95": float(np.percentile(x, 95)) if len(x) else 0.0,
        "p99": float(np.percentile(x, 99)) if len(x) else 0.0,
        "ci95_low": ci95(x)[0],
        "ci95_high": ci95(x)[1],
        "min": float(x.min()) if len(x) else 0.0,
        "max": float(x.max()) if len(x) else 0.0,
    }

def environment_metadata():
    import platform, sys
    meta={
        "python_version": sys.version,
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "cpu_count": os.cpu_count(),
    }
    try:
        import cryptography
        meta["cryptography_version"]=cryptography.__version__
    except Exception: pass
    try:
        import numpy
        meta["numpy_version"]=numpy.__version__
    except Exception: pass
    try:
        import psutil
        meta["psutil_version"]=psutil.__version__
        meta["physical_memory_gb"]=round(psutil.virtual_memory().total/1024**3,2)
    except Exception: pass
    return meta

def relative_overhead(baseline, treatment):
    return (treatment - baseline) / baseline * 100 if baseline else None

def mutate(policies, pid, field, value):
    for p in policies:
        if p.get("policy_id") == pid:
            p[field] = value
            return
    raise KeyError(pid)

def sign_policy(p, signer, hrot):
    q = copy.deepcopy(p)
    q.pop("signature", None); q.pop("signing_public_key", None); q.pop("hrot_tag", None)
    q["signature"] = signer.sign(bytes.fromhex(policy_hash(q)))
    q["signing_public_key"] = signer.public_key
    q["hrot_tag"] = hrot.seal(canonical_bytes(q))
    return q

def synthetic_policy(i, version=2, complexity="medium"):
    # Heterogeneous-but-schema-compatible synthetic policies.
    proto = ["tcp", "udp", "ip"][i % 3]
    decision = ["PERMIT", "DENY"][i % 2]
    extra = {}
    if complexity == "complex":
        extra = {
            "application": f"app-{i % 17}",
            "service_group": f"svc-{i % 11}",
            "device_group": f"dg-{i % 13}",
            "time_window": ["business_hours", "after_hours"][i % 2],
            "posture": ["compliant", "managed"][i % 2],
        }
    p = {
        "policy_id": f"POL-SYN-{i:06d}", "intent_id": f"SYN-{i:06d}",
        "subject": f"user_group_{i % 23}", "resource": f"resource_{i % 37}",
        "decision": decision,
        "src_ip": f"10.{(i//65536)%256}.{(i//256)%256}.{i%256} 0.0.0.255",
        "dst_ip": f"192.0.2.{(i % 250)+1}", "protocol": proto,
        "ios_command": f"{'permit' if decision == 'PERMIT' else 'deny'} {proto} synthetic {i}",
        "enforcement_point": f"PEP-{i % 8}", "status": "compiled", "version": version,
    }
    p.update(extra)
    return p

def fresh_baseline():
    policies = load_policies()
    signer, hrot = Signer(), SoftwareRootOfTrust()
    baseline = []
    for p in policies:
        q = copy.deepcopy(p)
        q.pop("signature", None); q.pop("signing_public_key", None); q.pop("hrot_tag", None)
        q["version"] = 2
        baseline.append(sign_policy(q, signer, hrot))
    save_policies(baseline); save_ledger([], LEDGER_FILE)
    for p in baseline:
        old = copy.deepcopy(p); old["version"] = 1
        old.pop("signature", None); old.pop("signing_public_key", None); old.pop("hrot_tag", None)
        old = sign_policy(old, signer, hrot)
        append("POLICY_COMPILED", old["policy_id"], old, LEDGER_FILE, "Historical authorized version 1",
               signer, 1, hrot_tag=old["hrot_tag"])
    for p in baseline:
        append("POLICY_COMPILED", p["policy_id"], p, LEDGER_FILE, "Current authorized version 2",
               signer, 2, hrot_tag=p["hrot_tag"])
    return baseline, load_ledger(LEDGER_FILE), signer, hrot

def attack_instance(baseline, ledger, attack_type, rng):
    p = copy.deepcopy(baseline)
    pid = p[rng.randrange(len(p))]["policy_id"]
    target = next(x for x in p if x["policy_id"] == pid)
    metadata = {"attack_type": attack_type, "policy_id": pid}
    if attack_type == "decision_flip":
        target["decision"] = "DENY" if target["decision"] == "PERMIT" else "PERMIT"
    elif attack_type == "source_address_change":
        target["src_ip"] = "172.16.0.0 0.0.0.255"
    elif attack_type == "destination_change":
        target["dst_ip"] = "198.51.100.10"
    elif attack_type == "protocol_change":
        target["protocol"] = "udp" if target["protocol"] != "udp" else "tcp"
    elif attack_type == "enforcement_command_change":
        target["ios_command"] = target["ios_command"] + " remark UNAUTHORIZED"
    elif attack_type == "enforcement_point_change":
        target["enforcement_point"] = "Unauthorized-PEP"
    elif attack_type == "stale_replay":
        old = next(r["artifact_data"] for r in ledger if r["artifact_id"] == pid and r.get("version") == 1)
        p[p.index(target)] = copy.deepcopy(old)
    elif attack_type == "forged_signature":
        target["signature"] = "00" * 64
    elif attack_type == "version_manipulation":
        target["version"] = int(target.get("version", 2)) + 1
    elif attack_type == "hrot_tag_tamper":
        target["hrot_tag"] = "00" * 32
    elif attack_type == "ledger_record_tamper":
        # Policy is unchanged; the attack is evaluated against ledger verification.
        if ledger:
            altered = copy.deepcopy(ledger)
            idx = rng.randrange(len(altered))
            altered[idx]["description"] = "UNAUTHORIZED LEDGER EDIT"
            metadata["altered_ledger"] = altered
    elif attack_type == "partial_deployment":
        # Remove one policy from the observed enforcement representation.
        if len(p) > 1:
            removed = p.pop(rng.randrange(len(p)))
            metadata["removed_policy_id"] = removed["policy_id"]
    return p, metadata

def benign_instance(baseline, kind):
    p = copy.deepcopy(baseline)
    target = p[0]
    if kind == "timestamp_change":
        target["timestamp"] = "2099-01-01T00:00:00Z"
    elif kind == "runtime_metadata_addition":
        target["runtime_id"] = "runtime-test-only"
        target["deployment_id"] = "deployment-test-only"
    elif kind == "key_reordering":
        # Rebuild dict in reverse insertion order. Canonicalization must remain invariant.
        p[0] = dict(reversed(list(target.items())))
    return p

def verify_mode(current, trusted, signer, hrot, mode, ledger_path=LEDGER_FILE):
    """Return a common result schema for ablation/baseline comparisons."""
    if mode == "none":
        return {"all_compliant": True, "results":[{"status":"COMPLIANT"} for _ in current]}
    results = []
    for p in current:
        t = trusted.get(p.get("policy_id"))
        if t is None:
            results.append({"status": "UNVERIFIABLE"})
            continue
        ch, th = policy_hash(p), policy_hash(t)
        hash_ok = ch == th
        sig_ok = True
        fresh_ok = True
        hrot_ok = True
        if mode in {"signed", "hash_sig", "full_no_hrot", "full"}:
            try: signer.verify(bytes.fromhex(ch), p.get("signature"), p.get("signing_public_key"))
            except Exception: sig_ok = False
        if mode in {"full_no_hrot", "full"}:
            fresh_ok = int(p.get("version", 0)) >= int(t.get("version", 0))
        if mode == "full":
            try: hrot_ok = hrot.verify(canonical_bytes(p), p.get("hrot_tag"))
            except Exception: hrot_ok = False
        if mode == "hash":
            compliant = hash_ok
        elif mode in {"signed", "hash_sig"}:
            compliant = hash_ok and sig_ok
        elif mode == "full_no_hrot":
            compliant = hash_ok and sig_ok and fresh_ok
        else:
            compliant = hash_ok and sig_ok and fresh_ok and hrot_ok
        results.append({"status": "COMPLIANT" if compliant else "VIOLATION",
                        "hash_ok": hash_ok, "signature_ok": sig_ok,
                        "freshness_ok": fresh_ok, "hrot_ok": hrot_ok})
    return {"all_compliant": all(x["status"] == "COMPLIANT" for x in results), "results": results}

def evaluate_security(baseline, ledger, signer, hrot, n_per_attack=100, seed=20260814):
    rng = random.Random(seed)
    trusted = trusted_policy_map(ledger)
    modes = ["none", "hash", "signed", "full_no_hrot", "full"]
    rows, aggregate = [], {}
    benign_total = len(BENIGN_TYPES) * max(10, min(n_per_attack, 100))
    benign_cases = [(k, i) for k in BENIGN_TYPES for i in range(max(10, min(n_per_attack, 100)))]
    for mode in modes:
        tp = fp = tn = fn = 0
        by_attack = {}
        for kind, i in benign_cases:
            cur = benign_instance(baseline, kind)
            r = verify_mode(cur, trusted, signer, hrot, mode)
            pred = not r["all_compliant"]
            fp += int(pred); tn += int(not pred)
            rows.append({"mode": mode, "case_id": f"B-{kind}-{i}", "actual": "benign",
                         "attack_type": kind, "predicted": "violation" if pred else "compliant"})
            by_attack.setdefault(kind, {"tp":0,"fn":0,"tn":0,"fp":0}); by_attack[kind]["fp"] += int(pred); by_attack[kind]["tn"] += int(not pred)
        for kind in ATTACK_TYPES:
            by_attack.setdefault(kind, {"tp":0,"fn":0,"tn":0,"fp":0})
            for i in range(n_per_attack):
                cur, meta = attack_instance(baseline, ledger, kind, rng)
                if kind == "ledger_record_tamper":
                    # Only the full IDCLM path claims ledger-integrity monitoring.
                    altered = meta["altered_ledger"]
                    pred = (not verify_chain_from_records(altered)["valid"]) if mode == "full" else False
                elif kind == "partial_deployment":
                    # A deployment-state completeness check is part of the full trust-layer
                    # evaluation; the simpler cryptographic baselines do not claim this.
                    pred = (set(x.get("policy_id") for x in cur) != set(trusted)) if mode == "full" else False
                else:
                    pred = not verify_mode(cur, trusted, signer, hrot, mode)["all_compliant"]
                tp += int(pred); fn += int(not pred)
                by_attack[kind]["tp"] += int(pred); by_attack[kind]["fn"] += int(not pred)
                rows.append({"mode": mode, "case_id": f"A-{kind}-{i}", "actual": "violation",
                             "attack_type": kind, "predicted": "violation" if pred else "compliant"})
        total = tp + tn + fp + fn
        f1 = 2*tp/(2*tp+fp+fn) if (2*tp+fp+fn) else 0
        aggregate[mode] = {
            "TN":tn,"FP":fp,"TP":tp,"FN":fn,
            "accuracy":(tn+tp)/total if total else 0,
            "precision":tp/(tp+fp) if tp+fp else 0,
            "recall":tp/(tp+fn) if tp+fn else 0,
            "f1":f1,
            "false_positive_rate":fp/(fp+tn) if fp+tn else 0,
            "false_negative_rate":fn/(fn+tp) if fn+tp else 0,
            "benign_observations":benign_total,
            "attack_observations":len(ATTACK_TYPES)*n_per_attack,
            "by_attack":by_attack
        }
    return aggregate, rows

def verify_chain_from_records(records):
    # Local copy of ledger verification for attack experiments.
    broken = []
    for i, rec in enumerate(records):
        fields=("record_id","sequence","timestamp","event_type","artifact_id","description",
                "artifact_data","version","previous_hash","merkle_root","approval_bundle","hrot_tag")
        import ledger
        content={k:rec.get(k) for k in fields}
        hash_ok=ledger.record_hash(content)==rec.get("record_hash")
        expected=ledger.GENESIS_HASH if i==0 else records[i-1].get("record_hash")
        if not(hash_ok and rec.get("previous_hash")==expected): broken.append(rec.get("sequence",i+1))
    return {"valid":not broken,"records":len(records),"broken_sequences":broken}

def ablation_study(baseline, ledger, signer, hrot, n_per_attack=100, seed=20260814):
    aggregate, rows = evaluate_security(baseline, ledger, signer, hrot, n_per_attack, seed)
    # The modes form the component ladder used in the manuscript.
    ladder = [
        ("none", "No cryptographic integrity protection"),
        ("hash", "SHA-256 state comparison only"),
        ("signed", "Hash + provenance signature"),
        ("full_no_hrot", "Hash + signature + freshness/version"),
        ("full", "Hash + signature + freshness + software HRoT + ledger/completeness checks"),
    ]
    return {"component_ladder": [{"mode":m,"description":d} for m,d in ladder],
            "aggregate":aggregate, "observations":rows}

def functional_and_recovery(baseline, ledger, signer, hrot):
    trusted = trusted_policy_map(ledger)
    rows = []
    clean = verify_policy_set(baseline, trusted, signer=signer, require_signature=True, hrot=hrot)
    rows.append({"scenario":"normal_operation","detected":not clean["all_compliant"],"pass":clean["all_compliant"]})
    for attack in ["decision_flip","stale_replay","forged_signature","hrot_tag_tamper"]:
        cur, meta = attack_instance(baseline, ledger, attack, random.Random(7))
        r = verify_policy_set(cur, trusted, signer=signer, require_signature=True, hrot=hrot)
        target = meta["policy_id"]
        detected = any(x.get("policy_id")==target and x.get("status")!="COMPLIANT" for x in r["results"])
        save_policies(cur)
        t0=time.perf_counter_ns()
        rb = RollbackManager(POLICIES_FILE,LEDGER_FILE,signer,hrot).rollback_policy(target, trusted[target])
        recovery_ms=(time.perf_counter_ns()-t0)/1e6
        rows.append({"scenario":attack,"policy_id":target,"detected":detected,
                     "rollback_success":rb["success"],"recovery_ms":recovery_ms,
                     "pass":detected and rb["success"]})
        save_policies(copy.deepcopy(baseline)); save_ledger(copy.deepcopy(ledger),LEDGER_FILE)
    return rows

def end_to_end_latency(baseline, ledger, signer, hrot, runs=100):
    trusted = trusted_policy_map(ledger)
    rng = random.Random(17)
    rows=[]
    for i in range(runs):
        cur, meta = attack_instance(baseline, ledger, "decision_flip", rng)
        t0=time.perf_counter_ns()
        # Software-emulated telemetry acquisition/serialization.
        telemetry = json.loads(json.dumps(cur, sort_keys=True))
        t1=time.perf_counter_ns()
        r = verify_policy_set(telemetry, trusted, signer=signer, require_signature=True, hrot=hrot)
        t2=time.perf_counter_ns()
        target=meta["policy_id"]
        rb=RollbackManager(POLICIES_FILE,LEDGER_FILE,signer,hrot)
        # Keep the package filesystem state isolated and measure actual rollback.
        save_policies(telemetry)
        rb_result=rb.rollback_policy(target,trusted[target])
        t3=time.perf_counter_ns()
        save_policies(copy.deepcopy(baseline)); save_ledger(copy.deepcopy(ledger),LEDGER_FILE)
        rows.append({
            "run":i+1,
            "telemetry_ms":(t1-t0)/1e6,
            "verification_ms":(t2-t1)/1e6,
            "rollback_ms":(t3-t2)/1e6,
            "end_to_end_ms":(t3-t0)/1e6,
            "detected":not r["all_compliant"],
            "rollback_success":rb_result["success"]
        })
    return rows

def scalability(signer, hrot, sizes, runs=5, seed=20260814):
    rng = random.Random(seed)
    raw=[]; summaries=[]
    for n in sizes:
        complexity = "simple" if n < 1000 else "complex"
        policies=[synthetic_policy(i, complexity=complexity) for i in range(1,n+1)]
        policies=[sign_policy(p,signer,hrot) for p in policies]
        trusted={p["policy_id"]:p for p in policies}
        hashes=[policy_hash(p) for p in policies]
        seq=[]; sig=[]; merkle_build=[]; proof_verify=[]
        for run in range(1,runs+1):
            ht,_=time_call(lambda:[policy_hash(p) for p in policies])
            vt,_=time_call(lambda:verify_policy_set(policies,trusted,signer=signer,require_signature=True,hrot=hrot))
            mt,_=time_call(lambda:merkle_root(hashes))
            idx=rng.randrange(n)
            proof=build_proof(hashes,idx)
            pt,_=time_call(lambda:verify_proof(hashes[idx],proof,merkle_root(hashes)))
            raw.append({"policies":n,"run":run,"hash_ms":ht,"sequential_verification_ms":vt,
                        "merkle_root_ms":mt,"merkle_proof_verification_ms":pt,
                        "policy_complexity":complexity,"proof_length":len(proof)})
            seq.append(vt); sig.append(ht); merkle_build.append(mt); proof_verify.append(pt)
        summaries.append({
            "policies":n,"policy_complexity":complexity,"runs":runs,
            "hash":summary(sig),"sequential_verification":summary(seq),
            "merkle_root":summary(merkle_build),"merkle_proof_verification":summary(proof_verify),
            "proof_length":len(build_proof(hashes,0))
        })
    return raw,summaries

def resource_overhead(baseline, ledger, signer, hrot, runs=20):
    """Measure process RSS where psutil is available; otherwise report unavailable."""
    try:
        import psutil
        proc=psutil.Process(os.getpid())
        rss=[]
        for _ in range(runs):
            before=proc.memory_info().rss
            trusted=trusted_policy_map(ledger)
            verify_policy_set(baseline,trusted,signer=signer,require_signature=True,hrot=hrot)
            after=proc.memory_info().rss
            rss.append((after-before)/1024**2)
        return {"available":True,"rss_delta_mb":summary(rss)}
    except Exception as e:
        return {"available":False,"reason":str(e)}

def write_csv(path, rows, fields):
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

def main(args=None):
    parser=argparse.ArgumentParser(description="IDCLM v5 upgraded evidence suite")
    parser.add_argument("--attack-runs",type=int,default=100)
    parser.add_argument("--timing-runs",type=int,default=100)
    parser.add_argument("--scale-runs",type=int,default=5)
    parser.add_argument("--sizes",type=str,default="5,10,50,100,500,1000,5000,10000")
    parser.add_argument("--seed",type=int,default=20260814)
    parser.add_argument("--skip-large",action="store_true")
    ns=parser.parse_args(args)
    sizes=[int(x) for x in ns.sizes.split(",") if x.strip()]
    if ns.skip_large: sizes=[x for x in sizes if x<=1000]

    original_p=load_policies(); original_l=load_ledger(LEDGER_FILE)
    try:
        baseline, ledger, signer, hrot=fresh_baseline()
        functional=functional_and_recovery(baseline,ledger,signer,hrot)
        ablation=ablation_study(baseline,ledger,signer,hrot,ns.attack_runs,ns.seed)
        e2e=end_to_end_latency(baseline,ledger,signer,hrot,ns.timing_runs)
        resources=resource_overhead(baseline,ledger,signer,hrot)
        raw_scale,scale= scalability(signer,hrot,sizes,ns.scale_runs,ns.seed)
        chain=verify_chain(LEDGER_FILE,signer)

        e2e_summary=summary([r["end_to_end_ms"] for r in e2e])
        e2e_summary["detection_rate"]=sum(r["detected"] for r in e2e)/len(e2e)
        e2e_summary["rollback_success_rate"]=sum(r["rollback_success"] for r in e2e)/len(e2e)

        # Regression for sequential verification and hash computation.
        x=np.asarray([r["policies"] for r in scale],float)
        regressions={}
        for key in ["hash","sequential_verification","merkle_root"]:
            y=np.asarray([r[key]["mean"] for r in scale],float)
            m,b=np.polyfit(x,y,1)
            r2=float(1-np.sum((y-(m*x+b))**2)/np.sum((y-y.mean())**2)) if len(y)>1 and np.sum((y-y.mean())**2)>0 else 1.0
            regressions[key]={"slope_ms_per_policy":float(m),"intercept_ms":float(b),"r2":r2}

        result={
            "package_version":"IB-NAC reproducibility package v5.0",
            "environment":environment_metadata(),
            "research_questions":{
                "RQ1":"Can IDCLM detect a broader set of enforcement-state integrity violations?",
                "RQ2":"What do provenance and HRoT components contribute relative to simpler baselines, and is freshness defense-in-depth measurable separately from the version-bound digest?",
                "RQ3":"What computational and recovery overhead does IDCLM introduce?",
                "RQ4":"How does verification scale with policy-set size and policy complexity?",
                "RQ5":"Does the software mechanism remain correct across benign canonicalization changes?"
            },
            "functional_and_recovery":functional,
            "ablation":{k:v for k,v in ablation.items() if k!="observations"},
            "end_to_end_software_emulation":{"summary":e2e_summary,"observations":e2e},
            "resource_overhead":resources,
            "scalability_summary":scale,
            "scalability_regression":regressions,
            "ledger_chain":chain,
            "scope_statement":"Software/emulation evidence only; no physical device, production controller, TPM/HSM, or distributed-consensus claim."
        }
        save_json(RESULTS/"complete_results_v5.json",result)
        save_json(RESULTS/"ablation_results.json",ablation)
        save_json(RESULTS/"scalability_results_v5.json",scale)
        save_json(RESULTS/"functional_recovery_v5.json",functional)
        save_json(RESULTS/"e2e_latency_results.json",{"summary":e2e_summary,"observations":e2e})
        save_json(RESULTS/"resource_overhead.json",resources)

        write_csv(RESULTS/"ablation_observations.csv",ablation["observations"],
                  ["mode","case_id","actual","attack_type","predicted"])
        write_csv(RESULTS/"e2e_latency_raw.csv",e2e,
                  ["run","telemetry_ms","verification_ms","rollback_ms","end_to_end_ms","detected","rollback_success"])
        write_csv(RESULTS/"scalability_raw_v5.csv",raw_scale,
                  ["policies","run","hash_ms","sequential_verification_ms","merkle_root_ms","merkle_proof_verification_ms","policy_complexity","proof_length"])
        return result
    finally:
        save_policies(original_p); save_ledger(original_l,LEDGER_FILE)

if __name__=="__main__":
    print(json.dumps(main(),indent=2))
