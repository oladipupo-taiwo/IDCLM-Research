"""Minimal Cisco Modeling Labs REST client for lab discovery and lifecycle.

CML 2.x exposes REST APIs for programmatic lab lifecycle and node operations.
The exact endpoint surface can vary by CML release; this client intentionally
uses the stable /labs and /labs/{lab_id}/nodes resources and allows the base
URL/token to be supplied at runtime.
"""
from __future__ import annotations
import os, requests

class CMLClient:
    def __init__(self, base_url=None, token=None, verify_tls=True):
        self.base_url = (base_url or os.environ["CML_URL"]).rstrip("/")
        self.token = token or os.environ.get("CML_TOKEN")
        self.verify_tls = verify_tls
        if not self.token: raise ValueError("Set CML_TOKEN or pass token")
    def _req(self, method, path, **kwargs):
        headers = kwargs.pop("headers", {})
        headers["Authorization"] = f"Bearer {self.token}"
        headers.setdefault("Accept", "application/json")
        if "json" in kwargs: headers.setdefault("Content-Type", "application/json")
        r = requests.request(method, self.base_url + path, headers=headers, verify=self.verify_tls, timeout=30, **kwargs)
        r.raise_for_status()
        return r.json() if r.content else None
    def list_labs(self): return self._req("GET", "/labs")
    def get_lab(self, lab_id): return self._req("GET", f"/labs/{lab_id}")
    def get_node(self, lab_id, node_id): return self._req("GET", f"/labs/{lab_id}/nodes/{node_id}")
    def patch_node(self, lab_id, node_id, payload): return self._req("PATCH", f"/labs/{lab_id}/nodes/{node_id}", json=payload)
    def start_lab(self, lab_id): return self._req("PUT", f"/labs/{lab_id}/state", json={"state":"STARTED"})
    def stop_lab(self, lab_id): return self._req("PUT", f"/labs/{lab_id}/state", json={"state":"STOPPED"})
