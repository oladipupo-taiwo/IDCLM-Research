"""SSH adapter for running Cisco CLI commands against CML virtual devices.

Requires optional Netmiko. It reads the actual running configuration, applies
configuration snippets, and therefore provides the device-state evidence that
Packet Tracer/Python-only experiments cannot provide.
"""
from __future__ import annotations
import os

class IOSDevice:
    def __init__(self, host, username=None, password=None, device_type="cisco_ios", port=22):
        self.name = host
        self.host = host; self.username = username or os.environ["DEVICE_USER"]
        self.password = password or os.environ["DEVICE_PASSWORD"]
        self.device_type = device_type; self.port = port
        self._conn = None
    def connect(self):
        from netmiko import ConnectHandler
        self._conn = ConnectHandler(device_type=self.device_type, host=self.host, username=self.username,
                                    password=self.password, port=self.port)
        return self
    def get_state(self):
        if self._conn is None: self.connect()
        return self._conn.send_command("show running-config", read_timeout=60)
    def apply_config(self, config):
        if self._conn is None: self.connect()
        commands=[x.strip() for x in config.splitlines() if x.strip() and not x.strip().startswith("!")]
        self._conn.send_config_set(commands, read_timeout=60)
        self._conn.save_config()
    def close(self):
        if self._conn: self._conn.disconnect(); self._conn=None
