"""Reproducible Mininet topology for IDCLM drift experiments.

Run on a Linux host with Mininet and Open vSwitch installed:
    sudo python3 topology.py --nodes 4
"""
import argparse

def build(n=4):
    from mininet.net import Mininet
    from mininet.node import OVSSwitch, Controller
    from mininet.link import TCLink
    from mininet.cli import CLI
    net=Mininet(controller=Controller, switch=OVSSwitch, link=TCLink, autoSetMacs=True)
    c=net.addController('c0')
    switches=[]
    for i in range(1,n+1): switches.append(net.addSwitch(f's{i}'))
    for i,s in enumerate(switches,1):
        h=net.addHost(f'h{i}')
        net.addLink(h,s,bw=100)
    for a,b in zip(switches,switches[1:]): net.addLink(a,b,bw=1000)
    net.start(); CLI(net); net.stop()

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--nodes',type=int,default=4); args=p.parse_args(); build(args.nodes)
