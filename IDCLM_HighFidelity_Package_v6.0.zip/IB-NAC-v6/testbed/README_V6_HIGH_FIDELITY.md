# IDCLM v6 High-Fidelity Validation Package

## Purpose

v6 adds the missing high-fidelity validation layer to the v5 reproducibility package. It is designed to run against **actual running network-device state** in Cisco Modeling Labs (CML) and against **Mininet/Open vSwitch** for repeatable scale experiments.

The package does **not** fabricate CML or Mininet results. Results become manuscript evidence only after the experiments are executed on the target environment and the raw CSV/JSON files are preserved.

## What is newly validated

1. Actual running configuration retrieval from a Cisco virtual network OS.
2. Unauthorized configuration drift injected into the running device.
3. Detection by comparing trusted and observed device state.
4. Verified restoration of the authorized configuration.
5. Independent freshness/replay semantics in which policy content identity is separated from version/epoch state.
6. Mininet/OVS topology for repeatable multi-switch experiments.

## Recommended CML lab

Use IOSv and IOSv-L2 or other appropriate Cisco reference platforms available in your licensed CML release. A small initial lab should contain:

- 1 router
- 3 switches
- 2 protected servers/hosts
- 3 security zones: Finance, IT, Guest
- 1 Linux management/IDCLM node

CML 2.x provides REST APIs for programmatic lab lifecycle and node operations. The package therefore includes a lightweight REST client plus an SSH device adapter. Actual running-state collection is performed through the device CLI so the experiment measures the state of a running network OS rather than a static topology artifact.

## CML environment variables

```bash
export CML_URL=https://<cml-server>/api/v0
export CML_TOKEN=<api-token>
export DEVICE_USER=<ios-user>
export DEVICE_PASSWORD=<ios-password>
```

The CML API surface can differ across releases. Confirm the exact API endpoint/authentication contract in the CML UI under **Tools > API Documentation** before execution.

## Install optional high-fidelity dependencies

```bash
pip install requests netmiko
```

For Mininet, install Mininet and Open vSwitch using the distribution-supported method on the Linux test host.

## CML drift experiment

First ensure the target IOS device is reachable by SSH and that the trusted and malicious configuration snippets are appropriate for the device/interface addressing used in the lab.

```bash
python3 testbed/experiments/exp_device_drift.py --host <IOS-IP>
```

The experiment:

1. applies the trusted state;
2. retrieves `show running-config`;
3. applies an unauthorized change;
4. retrieves the actual running state again;
5. computes trusted/observed digests;
6. detects drift;
7. restores the trusted configuration;
8. retrieves the running state again;
9. verifies successful restoration;
10. writes raw timing and outcome data.

Repeat this experiment at least 30 times per attack class for manuscript evidence; 100 runs are preferred for the principal latency experiment.

## Replay experiment

The v6 replay test deliberately separates policy content from freshness metadata:

```bash
python3 testbed/experiments/exp_replay_v6.py
```

A correct v6 implementation should produce the same content digest for two versions of unchanged policy content while rejecting the older version when it is replayed after a newer trusted version.

## Mininet

```bash
sudo python3 testbed/mininet/topology.py --nodes 10
```

The topology is intentionally small and transparent. Extend the experiment runner to inject ACL/flow drift into selected switches and measure detection and recovery over 10, 50, 100, 500, and 1,000 enforcement points.

## Manuscript evidence rule

Do not transfer any CML/Mininet number into the paper unless the corresponding raw result file, environment metadata, and experiment log exist. The manuscript should distinguish:

- v5 software validation;
- CML virtual-device validation; and
- Mininet/OVS scalability validation.

CML is a virtual network simulation environment. It validates network-OS control/management behavior but does not establish ASIC-level physical forwarding timing.
