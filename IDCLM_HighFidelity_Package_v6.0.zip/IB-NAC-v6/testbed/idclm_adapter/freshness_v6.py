"""V6 freshness model: policy content identity is separated from freshness state.

This module deliberately separates the canonical content digest H(P) from the
monotonic version/epoch state used for anti-replay decisions. This addresses a
validation limitation in v5, where version was already part of the canonical
policy digest and freshness could not be isolated experimentally.
"""
from __future__ import annotations
import base64, hashlib, json, time
from dataclasses import dataclass
from typing import Any, Mapping

VOLATILE = {"timestamp","record_id","created_at","updated_at","deployment_id","runtime_id"}
FRESHNESS_FIELDS = {"version", "epoch", "issued_at", "expires_at"}

def content_view(policy: Mapping[str, Any]) -> dict[str, Any]:
    def clean(v):
        if isinstance(v, Mapping):
            return {str(k): clean(x) for k,x in sorted(v.items(), key=lambda kv: str(kv[0]))
                    if str(k) not in VOLATILE and str(k) not in FRESHNESS_FIELDS}
        if isinstance(v, list): return [clean(x) for x in v]
        return v
    return clean(dict(policy))

def content_bytes(policy: Mapping[str, Any]) -> bytes:
    return json.dumps(content_view(policy), sort_keys=True, separators=(",",":"), ensure_ascii=False).encode()

def content_digest(policy: Mapping[str, Any]) -> str:
    return hashlib.sha256(content_bytes(policy)).hexdigest()

def freshness_record(policy: Mapping[str, Any]) -> dict[str, Any]:
    return {"version": int(policy.get("version", 0)), "epoch": int(policy.get("epoch", 0)),
            "issued_at": int(policy.get("issued_at", 0)), "expires_at": policy.get("expires_at")}

def freshness_ok(current: Mapping[str,Any], trusted: Mapping[str,Any], now: int | None = None) -> bool:
    now = int(time.time()) if now is None else int(now)
    cv, tv = freshness_record(current), freshness_record(trusted)
    if cv["version"] < tv["version"]: return False
    if cv["epoch"] < tv["epoch"]: return False
    if cv["expires_at"] is not None and now > int(cv["expires_at"]): return False
    return True

@dataclass
class FreshnessAuthority:
    epoch: int = 1
    last_version: int = 0
    def issue(self, policy: Mapping[str,Any], version: int | None = None, ttl: int | None = None) -> dict[str,Any]:
        v = self.last_version + 1 if version is None else int(version)
        if v <= self.last_version: raise ValueError("version must increase monotonically")
        self.last_version = v
        out = dict(policy); out["version"] = v; out["epoch"] = self.epoch; out["issued_at"] = int(time.time())
        if ttl is not None: out["expires_at"] = out["issued_at"] + int(ttl)
        return out
