"""Device-state abstraction used by CML and Mininet experiments."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol

class DeviceAdapter(Protocol):
    name: str
    def get_state(self) -> str: ...
    def apply_config(self, config: str) -> None: ...

@dataclass
class MockDevice:
    name: str
    state: str
    def get_state(self) -> str: return self.state
    def apply_config(self, config: str) -> None: self.state = config
