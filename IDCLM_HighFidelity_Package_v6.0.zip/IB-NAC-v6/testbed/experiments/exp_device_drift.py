"""Core high-fidelity experiment: observe actual device state, inject drift, detect, rollback."""
from __future__ import annotations
import argparse, csv, json, time
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from testbed.idclm_adapter.freshness_v6 import content_digest, freshness_ok


def run(device, trusted_config, malicious_config, out_csv):
    device.apply_config(trusted_config)
    baseline=device.get_state()
    t0=time.perf_counter_ns(); device.apply_config(malicious_config); t1=time.perf_counter_ns()
    observed=device.get_state(); t2=time.perf_counter_ns()
    baseline_hash=content_digest({'device_state':baseline})
    observed_hash=content_digest({'device_state':observed})
    detected=baseline_hash != observed_hash
    if detected: device.apply_config(trusted_config)
    restored=device.get_state(); t3=time.perf_counter_ns()
    rollback_ok=content_digest({'device_state':restored})==baseline_hash
    row={'device':device.name,'detected':detected,'rollback_ok':rollback_ok,
         'inject_ms':(t1-t0)/1e6,'observe_ms':(t2-t1)/1e6,'rollback_ms':(t3-t2)/1e6,
         'e2e_ms':(t3-t0)/1e6}
    Path(out_csv).parent.mkdir(parents=True,exist_ok=True)
    with open(out_csv,'w',newline='') as f: csv.DictWriter(f,fieldnames=row).writeheader(); csv.DictWriter(f,fieldnames=row).writerow(row)
    return row

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--host',required=True); p.add_argument('--out',default='testbed/results/device_drift.csv'); p.add_argument('--trusted-config',default='testbed/configs/trusted_ios.cfg'); p.add_argument('--malicious-config',default='testbed/configs/malicious_ios.cfg'); args=p.parse_args()
    from testbed.cml.ssh_device import IOSDevice
    d=IOSDevice(args.host); print(json.dumps(run(d,Path(args.trusted_config).read_text(),Path(args.malicious_config).read_text(),args.out),indent=2)); d.close()
