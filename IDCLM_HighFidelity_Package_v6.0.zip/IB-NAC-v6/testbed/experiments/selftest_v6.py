from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from testbed.idclm_adapter.device import MockDevice
from testbed.experiments.exp_device_drift import run
from testbed.experiments.exp_replay_v6 import run as replay

def main():
    d=MockDevice('mock-ios','TRUSTED\n')
    r=run(d,'TRUSTED\n','MALICIOUS\n','testbed/results/selftest_device_drift.csv')
    assert r['detected'] and r['rollback_ok']
    rr=replay(); assert rr['stale_replay_rejected']
    print('V6 self-test PASS', r, rr)
if __name__=='__main__': main()
