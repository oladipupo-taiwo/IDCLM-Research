"""Independent freshness/replay experiment for v6."""
from testbed.idclm_adapter.freshness_v6 import FreshnessAuthority, content_digest, freshness_ok

def run():
    a=FreshnessAuthority(epoch=7)
    base={'policy_id':'P1','decision':'DENY','src_ip':'10.0.0.0/24','dst_ip':'10.0.2.10'}
    v1=a.issue(base,version=1); v2=a.issue(base,version=2)
    assert content_digest(v1)==content_digest(v2), 'content digest must exclude freshness fields'
    assert freshness_ok(v2,v1)
    assert not freshness_ok(v1,v2)
    return {'content_digest_equal_across_versions':True,'new_version_accepted':True,'stale_replay_rejected':True}

if __name__=='__main__': print(run())
