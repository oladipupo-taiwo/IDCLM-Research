"""Replicated local ledger adapter with quorum validation; not a public blockchain."""
from __future__ import annotations
import hashlib,json,time
class LocalReplicatedLedger:
    def __init__(self,nodes=3,quorum=2): self.nodes=[[] for _ in range(nodes)]; self.quorum=quorum
    def _hash(self,b): return hashlib.sha256(json.dumps(b,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    def append(self,payload):
        prev=self.nodes[0][-1]["hash"] if self.nodes[0] else "0"*64
        block={"index":len(self.nodes[0]),"timestamp":time.time_ns(),"previous_hash":prev,"payload":payload}
        block["hash"]=self._hash(block)
        for n in self.nodes: n.append(dict(block))
        return block
    def verify_quorum(self):
        valid=0
        for chain in self.nodes:
            ok=True
            for i,b in enumerate(chain):
                prev="0"*64 if i==0 else chain[i-1]["hash"]
                content={k:b[k] for k in ("index","timestamp","previous_hash","payload")}
                if b["previous_hash"]!=prev or self._hash(content)!=b["hash"]: ok=False; break
            valid += ok
        return {"valid":valid>=self.quorum,"valid_nodes":valid,"nodes":len(self.nodes),"quorum":self.quorum}
