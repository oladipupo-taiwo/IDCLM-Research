"""Threshold authorization using independent Ed25519 approvals.
This is a real k-of-n authorization layer, not a FROST implementation."""
from __future__ import annotations
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
class ThresholdAuthority:
    def __init__(self,n=3,k=2):
        if not 1<=k<=n: raise ValueError("invalid threshold")
        self.n=n; self.k=k; self.keys=[Ed25519PrivateKey.generate() for _ in range(n)]
    def approvals(self,message:bytes,indices): return [{"signer":i,"signature":self.keys[i].sign(message).hex()} for i in indices]
    def verify(self,message:bytes,approvals):
        valid=0
        for a in approvals:
            try:self.keys[a["signer"]].public_key().verify(bytes.fromhex(a["signature"]),message);valid+=1
            except Exception:pass
        return {"valid_approvals":valid,"required":self.k,"authorized":valid>=self.k}

def demo(threshold=2,shares=3):
    a=ThresholdAuthority(shares,threshold); msg=b"IDCLM policy activation"; good=a.approvals(msg,list(range(threshold))); bad=a.approvals(msg,[0])
    return {"threshold":threshold,"signers":shares,"authorized_with_threshold":a.verify(msg,good),"rejected_below_threshold":a.verify(msg,bad),"implementation_status":"k-of-n Ed25519 authorization; not FROST"}
