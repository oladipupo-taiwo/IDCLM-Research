"""Merkle root and inclusion proof implementation."""
from __future__ import annotations
import hashlib

def h(x:bytes)->bytes:return hashlib.sha256(x).digest()
def leaf_hash(policy_hash_hex:str)->bytes:return h(bytes.fromhex(policy_hash_hex))
def merkle_root(policy_hashes):
    nodes=[leaf_hash(x) for x in policy_hashes]
    if not nodes:return h(b"").hex()
    while len(nodes)>1:
        if len(nodes)%2:nodes.append(nodes[-1])
        nodes=[h(nodes[i]+nodes[i+1]) for i in range(0,len(nodes),2)]
    return nodes[0].hex()
def build_proof(policy_hashes,index):
    nodes=[leaf_hash(x) for x in policy_hashes]; idx=index; proof=[]
    while len(nodes)>1:
        if len(nodes)%2:nodes.append(nodes[-1])
        sibling=idx-1 if idx%2 else idx+1; side="left" if idx%2 else "right"; proof.append((side,nodes[sibling].hex()))
        nodes=[h(nodes[i]+nodes[i+1]) for i in range(0,len(nodes),2)]; idx//=2
    return proof
def verify_proof(policy_hash_hex,proof,root_hex):
    node=leaf_hash(policy_hash_hex)
    for side,sib in proof: node=h(bytes.fromhex(sib)+node) if side=="left" else h(node+bytes.fromhex(sib))
    return node.hex()==root_hex
