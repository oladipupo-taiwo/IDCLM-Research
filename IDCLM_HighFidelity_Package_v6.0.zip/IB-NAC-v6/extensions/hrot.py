"""HRoT integration interface plus software test adapter; not a physical TPM."""
from __future__ import annotations
import hashlib,hmac,secrets
class SoftwareRootOfTrust:
    def __init__(self,key=None): self.key=key or secrets.token_bytes(32)
    def seal(self,data:bytes)->str: return hmac.new(self.key,data,hashlib.sha256).hexdigest()
    def verify(self,data:bytes,tag:str)->bool: return hmac.compare_digest(self.seal(data),tag)
    def attest(self,measurement:bytes)->dict: return {"measurement":hashlib.sha256(measurement).hexdigest(),"attested":True,"mode":"software-adapter"}
    @property
    def implementation_status(self): return "software HRoT adapter; physical TPM/HSM not exercised"
