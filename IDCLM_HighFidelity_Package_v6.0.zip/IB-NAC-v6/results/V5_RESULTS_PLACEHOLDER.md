# v5 results directory

Run `python measurements_v5.py` to generate the upgraded raw and aggregate evidence files.

The package intentionally does not ship pre-generated v5 numerical results so that manuscript claims are regenerated on the final experimental machine.
