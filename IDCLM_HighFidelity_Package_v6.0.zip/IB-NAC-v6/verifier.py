"""Integrity, provenance and freshness verifier."""
from __future__ import annotations
from ledger import policy_hash, verify_chain
from normalizer import normalize_policy, canonical_bytes

def trusted_policy_map(records):
    out={}
    for r in records:
        if r.get("event_type")=="POLICY_COMPILED":
            p=dict(r["artifact_data"]); p["version"]=int(r.get("version",p.get("version",1))); out[r["artifact_id"]]=p
    return out

def verify_policy(current,trusted,signer=None,current_version=None,require_signature=False,hrot=None):
    cn=normalize_policy(current); tn=normalize_policy(trusted)
    ch=policy_hash(current); th=policy_hash(trusted)
    version=int(current.get("version",0)); trusted_version=int(trusted.get("version",0))
    freshness = version >= trusted_version
    replay = version < trusted_version
    sig_ok=True
    if require_signature:
        sig=current.get("signature"); pub=current.get("signing_public_key")
        try:
            signer.verify(bytes.fromhex(ch),sig,pub); sig_ok=True
        except Exception: sig_ok=False
    hrot_ok=True
    if hrot and current.get("hrot_tag"):
        hrot_ok=hrot.verify(canonical_bytes(current),current["hrot_tag"])
    compliant=(ch==th and cn==tn and freshness and sig_ok and hrot_ok)
    if replay: status="REPLAY"
    elif ch!=th or cn!=tn: status="TAMPERED"
    elif not sig_ok: status="FORGED"
    elif not hrot_ok: status="HRoT_TAMPERED"
    else: status="COMPLIANT"
    return {"policy_id":current.get("policy_id"),"status":status,"current_hash":ch,"trusted_hash":th,
            "normalized_equal":cn==tn,"hash_equal":ch==th,"version":version,"trusted_version":trusted_version,
            "freshness_ok":freshness,"signature_ok":sig_ok,"hrot_ok":hrot_ok}

def verify_policy_set(current,trusted,verify_ledger=False,ledger_path="audit_ledger.json",**kwargs):
    results=[]
    for p in current:
        t=trusted.get(p.get("policy_id"))
        results.append({"policy_id":p.get("policy_id"),"status":"UNVERIFIABLE"} if t is None else verify_policy(p,t,**kwargs))
    chain=verify_chain(ledger_path) if verify_ledger else None
    counts={s:sum(r.get("status")==s for r in results) for s in {r.get("status") for r in results}}
    return {"policies_checked":len(current),"compliant":counts.get("COMPLIANT",0),
            "tampered":counts.get("TAMPERED",0),"replay":counts.get("REPLAY",0),
            "forged":counts.get("FORGED",0),"unverifiable":counts.get("UNVERIFIABLE",0),
            "all_compliant":all(r.get("status")=="COMPLIANT" for r in results),"results":results,"ledger_chain":chain}
