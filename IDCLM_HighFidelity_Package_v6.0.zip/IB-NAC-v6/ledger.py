"""Cryptographically protected sequential ledger with signed provenance."""
from __future__ import annotations
import hashlib, json, uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from normalizer import canonical_bytes

GENESIS_HASH = "0" * 64
LEDGER_FILE = Path("audit_ledger.json")

def sha256_bytes(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def policy_hash(policy: dict[str,Any]) -> str: return sha256_bytes(canonical_bytes(policy))
def _content_bytes(content: dict[str,Any]) -> bytes:
    return json.dumps(content, sort_keys=True, separators=(",",":"), ensure_ascii=False).encode("utf-8")
def record_hash(content: dict[str,Any]) -> str: return sha256_bytes(_content_bytes(content))

def load(path: Path=LEDGER_FILE) -> list[dict[str,Any]]:
    if not path.exists(): return []
    return json.loads(path.read_text(encoding="utf-8"))

def save(records: list[dict[str,Any]], path: Path=LEDGER_FILE) -> None:
    path.write_text(json.dumps(records, indent=2, ensure_ascii=False), encoding="utf-8")
def tip(records): return records[-1]["record_hash"] if records else GENESIS_HASH

def append(event_type:str, artifact_id:str, artifact_data:Any, path:Path=LEDGER_FILE,
           description:str="", signer=None, version:int|None=None, merkle_root:str|None=None,
           approval_bundle:dict|None=None, hrot_tag:str|None=None) -> dict[str,Any]:
    records=load(path)
    content={"record_id":str(uuid.uuid4()),"sequence":len(records)+1,
             "timestamp":datetime.now(timezone.utc).isoformat(),"event_type":event_type,
             "artifact_id":artifact_id,"description":description,"artifact_data":artifact_data,
             "version":version,"previous_hash":tip(records),"merkle_root":merkle_root,
             "approval_bundle":approval_bundle,"hrot_tag":hrot_tag}
    rec=dict(content); rec["record_hash"]=record_hash(content)
    if signer is not None:
        rec["signature"]=signer.sign(bytes.fromhex(rec["record_hash"]))
        rec["signing_public_key"]=signer.public_key
    else:
        rec["signature"]=None; rec["signing_public_key"]=None
    records.append(rec); save(records,path); return rec

def verify_chain(path:Path=LEDGER_FILE, signer=None) -> dict[str,Any]:
    records=load(path); broken=[]; signature_fail=[]
    for i,rec in enumerate(records):
        fields=("record_id","sequence","timestamp","event_type","artifact_id","description",
                "artifact_data","version","previous_hash","merkle_root","approval_bundle","hrot_tag")
        content={k:rec.get(k) for k in fields}
        hash_ok=record_hash(content)==rec.get("record_hash")
        expected=GENESIS_HASH if i==0 else records[i-1].get("record_hash")
        link_ok=rec.get("previous_hash")==expected
        if not(hash_ok and link_ok): broken.append(rec.get("sequence",i+1))
        if signer is not None and rec.get("signature"):
            try: signer.verify(bytes.fromhex(rec["record_hash"]),rec["signature"],rec.get("signing_public_key"));
            except Exception: signature_fail.append(rec.get("sequence",i+1))
    return {"valid":not broken and not signature_fail,"records":len(records),"broken_sequences":broken,"signature_failures":signature_fail}

def initialize_policy_records(policies:Iterable[dict[str,Any]],path:Path=LEDGER_FILE,signer=None,hrot=None)->int:
    records=load(path)
    if records:return 0
    for i,p in enumerate(policies,1):
        p2=dict(p); p2["version"]=int(p2.get("version",i))
        tag=hrot.seal(canonical_bytes(p2)) if hrot else None
        append("POLICY_COMPILED",p2["policy_id"],p2,path,"Trusted policy baseline",signer,p2["version"],hrot_tag=tag)
    return len(list(policies)) if not isinstance(policies,list) else len(policies)
