# IB-NAC / IDCLM Reproducibility Package v4.0

## Purpose

This package is the executable implementation accompanying the revised IB-NAC/IDCLM manuscript. The v4.0 implementation was expanded to address the principal consistency weaknesses identified during manuscript audit: stale-policy replay, explicit policy provenance, cryptographically verified rollback, Merkle integrity proofs, threshold authorization, and management-plane trust adapters.

## Experimentally evaluated core

1. **Deterministic policy normalization** (`normalizer.py`). Volatile runtime fields are excluded from the protected semantic representation and the remaining policy state is canonically serialized.
2. **Sequential SHA-256 hash chain** (`ledger.py`). Each record binds its payload to the previous record hash.
3. **Ed25519 policy provenance** (`security.py`, `ledger.py`). Authorized policy states and ledger records can be cryptographically signed and independently verified.
4. **Monotonic policy freshness/versioning** (`verifier.py`). A previously authorized but stale policy version is rejected as `REPLAY`.
5. **Policy-integrity verification** (`verifier.py`). Hash, normalized-state, signature, freshness and optional HRoT-tag checks are evaluated.
6. **Cryptographically verified rollback** (`rollback/manager.py`). A detected policy is restored to the trusted state and immediately re-verified; the rollback event is itself appended to the audit ledger.
7. **Merkle inclusion proofs** (`extensions/merkle_tree.py`). Root construction and per-policy inclusion proofs are executed and measured alongside the sequential mechanism.
8. **2-of-3 threshold authorization** (`extensions/threshold_signatures.py`). Policy activation can require two independent Ed25519 approvals. This is a real k-of-n authorization demonstration, but it is not a production FROST implementation.

## Management-plane extensions

- `extensions/hrot.py` provides an executable **software HRoT adapter** with sealing and attestation semantics. It is not a physical TPM/HSM and therefore does not establish hardware-backed security.
- `extensions/blockchain.py` provides a **replicated local-ledger adapter** with quorum validation across three local nodes. It is not a production distributed blockchain or consensus network.

These adapters allow the architectural intent in the manuscript to be exercised in code while preserving the distinction between prototype evidence and physical/distributed deployment evidence.

## Experiments

Run the complete experiment from the `IB-NAC` directory:

```bash
python measurements.py
```

The experiment covers:

- normal operation;
- unauthorized policy modification;
- policy drift;
- stale authorized-policy replay;
- forged-signature detection;
- automated rollback;
- 50 benign and 25 independent attack observations;
- SHA-256 hashing;
- signed integrity verification;
- detection latency;
- sequential scalability from 5 to 1,000 policies;
- Merkle-root and inclusion-proof measurements;
- HRoT adapter attestation;
- replicated-ledger quorum validation;
- 2-of-3 threshold authorization.

## Output files

### JSON

- `results/complete_results.json` — complete machine-readable experiment summary.
- `results/confusion_matrix.json` — confusion matrix and classification metrics.
- `results/scalability_results.json` — aggregate scalability results.
- `results/merkle_results.json` — Merkle proof results.
- `results/extensions_results.json` — HRoT, replicated-ledger and threshold-authorization results.

### Raw CSV

- `results/performance_raw.csv` — individual timing observations.
- `results/scalability_raw.csv` — all 5–1,000 policy scalability runs.
- `results/confusion_matrix_observations.csv` — every classification observation, including attack type.

## Current clean v4.0 run

The development run completed successfully with:

- TN = 50
- FP = 0
- FN = 0
- TP = 25
- five-policy mean hash computation = 0.068498 ms
- five-policy mean signed integrity verification = 1.124041 ms
- mean detection latency = 0.866097 ms
- 1,000-policy mean hash computation = 11.127241 ms
- 1,000-policy mean signed integrity verification = 164.475971 ms
- 1,000-policy mean Merkle-root construction = 0.957427 ms
- sequential hash scalability R² = 0.999917
- sequential verification scalability R² = 0.999852
- Merkle-root scalability R² = 0.999077
- Merkle proof length at 1,000 policies = 10 hashes
- Merkle proof verification = successful
- HRoT adapter attestation = successful
- replicated ledger = 3/3 valid nodes with 2-node quorum
- 2-of-3 authorization = accepted
- 1-of-3 authorization = rejected

These values are measurements from the current implementation and should be treated as the ground truth for the next manuscript revision.

## Reproducibility rule

Never manually edit numerical results to match an earlier manuscript draft. If implementation changes alter the measurements, regenerate the outputs and revise the manuscript accordingly.

## Scope

The package provides executable evidence for the implemented prototype mechanisms. The software HRoT adapter does not prove TPM/HSM protection; the replicated ledger does not prove production blockchain consensus; and the threshold module does not prove FROST or another distributed threshold-signature protocol. Production deployment claims therefore require separate hardware and distributed-system validation.
