"""IDCLM/IB-NAC v4.0 reproducibility experiment.

Core evaluated mechanisms:
- deterministic policy normalization
- SHA-256 sequential hash chain
- Ed25519 policy provenance signatures
- monotonic policy-version freshness / replay detection
- integrity verification
- cryptographically verified rollback
- Merkle inclusion proofs
- k-of-n threshold authorization

Integration adapters additionally exercise a software HRoT interface and a
replicated local-ledger adapter. They are not evidence of physical TPM/HSM or
production blockchain deployment.
"""
from __future__ import annotations
import argparse, copy, csv, json, statistics, time
from pathlib import Path
import numpy as np
from ledger import append, load as load_ledger, save as save_ledger, verify_chain, policy_hash, GENESIS_HASH
from normalizer import canonical_bytes
from security import Signer
from verifier import trusted_policy_map, verify_policy_set, verify_policy
from rollback.manager import RollbackManager
from extensions.hrot import SoftwareRootOfTrust
from extensions.merkle_tree import merkle_root, build_proof, verify_proof
from extensions.blockchain import LocalReplicatedLedger
from extensions.threshold_signatures import ThresholdAuthority

BASE=Path(__file__).resolve().parent; RESULTS=BASE/"results"; RESULTS.mkdir(exist_ok=True)
POLICIES_FILE=BASE/"compiled_policies.json"; LEDGER_FILE=BASE/"audit_ledger.json"
RUNS=10; ATTACK_RUNS=25; BENIGN_RUNS=50; REPLAY_RUNS=10
SCALABILITY_SIZES=[5,10,25,50,100,200,500,1000]; SCALABILITY_RUNS=10

def load_json(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def save_json(p,o): Path(p).write_text(json.dumps(o,indent=2,ensure_ascii=False),encoding="utf-8")
def load_policies(): return load_json(POLICIES_FILE)
def save_policies(p): save_json(POLICIES_FILE,p)
def time_call(fn):
    t=time.perf_counter_ns(); r=fn(); return (time.perf_counter_ns()-t)/1e6,r

def mutate(policies,pid,field,value):
    for p in policies:
        if p.get("policy_id")==pid: p[field]=value; return
    raise KeyError(pid)

def sign_policy(p,signer,hrot):
    q=copy.deepcopy(p); q["signature"]=signer.sign(bytes.fromhex(policy_hash(q))); q["signing_public_key"]=signer.public_key
    q["hrot_tag"]=hrot.seal(canonical_bytes(q))
    return q

def synthetic_policy(i,version=2):
    return {"policy_id":f"POL-SYN-{i:05d}","intent_id":f"SYN-{i:05d}","subject":"synthetic_user","resource":"synthetic_resource","decision":"PERMIT",
            "src_ip":f"10.{(i//65536)%256}.{(i//256)%256}.{i%256} 0.0.0.255","dst_ip":"192.0.2.1","protocol":"tcp",
            "ios_command":f"permit tcp synthetic {i}","enforcement_point":"Synthetic-PEP","status":"compiled","version":version}

def fresh_baseline():
    policies=load_policies()
    signer=Signer(); hrot=SoftwareRootOfTrust()
    # Normalize the five prototype policies into version 2 trusted state.
    baseline=[]
    for i,p in enumerate(policies,1):
        q=copy.deepcopy(p); q.pop("signature",None); q.pop("signing_public_key",None); q.pop("hrot_tag",None); q["version"]=2
        baseline.append(sign_policy(q,signer,hrot))
    save_policies(baseline); save_ledger([],LEDGER_FILE)
    # Preserve version 1 historical states for replay testing.
    for p in baseline:
        old=copy.deepcopy(p); old["version"]=1; old.pop("signature",None); old.pop("signing_public_key",None); old.pop("hrot_tag",None); old=sign_policy(old,signer,hrot)
        append("POLICY_COMPILED",old["policy_id"],old,LEDGER_FILE,"Historical authorized version 1",signer,1,hrot_tag=old["hrot_tag"])
    for p in baseline:
        append("POLICY_COMPILED",p["policy_id"],p,LEDGER_FILE,"Current authorized version 2",signer,2,hrot_tag=p["hrot_tag"])
    return baseline,load_ledger(LEDGER_FILE),signer,hrot

def functional_tests(baseline,ledger,signer,hrot):
    trusted=trusted_policy_map(ledger); rows=[]; save_policies(copy.deepcopy(baseline))
    clean=verify_policy_set(load_policies(),trusted,verify_ledger=True,ledger_path=LEDGER_FILE,signer=signer,require_signature=True,hrot=hrot)
    rows.append({"scenario":"Normal operation","status":"COMPLIANT","detected":0,"rollback_success":None,"pass":clean["all_compliant"]})
    for scenario,pid,value in [("Unauthorized policy modification","POL-INT-001","DENY"),("Policy drift","POL-INT-003","PERMIT")]:
        tampered=copy.deepcopy(baseline); mutate(tampered,pid,"decision",value); save_policies(tampered)
        r=verify_policy_set(load_policies(),trusted,signer=signer,require_signature=True,hrot=hrot)
        rb=RollbackManager(POLICIES_FILE,LEDGER_FILE,signer,hrot).rollback_policy(pid,trusted[pid])
        rows.append({"scenario":scenario,"status":r["results"][next(i for i,x in enumerate(r["results"]) if x["policy_id"]==pid)]["status"],"detected":r["tampered"]+r["forged"]+r["replay"],"rollback_success":rb["success"],"pass":rb["success"]})
        save_policies(copy.deepcopy(baseline)); save_ledger(copy.deepcopy(ledger),LEDGER_FILE)
    # Freshness/replay attack using a validly signed historical v1 policy.
    old=next(r["artifact_data"] for r in ledger if r["event_type"]=="POLICY_COMPILED" and r["artifact_id"]=="POL-INT-001" and r["version"]==1)
    replay=copy.deepcopy(baseline); replay[0]=copy.deepcopy(old); save_policies(replay)
    rr=verify_policy_set(load_policies(),trusted,signer=signer,require_signature=True,hrot=hrot)
    rows.append({"scenario":"Stale authorized-policy replay","status":rr["results"][0]["status"],"detected":rr["replay"],"rollback_success":None,"pass":rr["replay"]==1})
    save_policies(copy.deepcopy(baseline))
    return rows

def performance_measurement(baseline,ledger,signer,hrot):
    trusted=trusted_policy_map(ledger); ht=[]; vt=[]; lat=[]; merkle=[]
    for _ in range(RUNS):
        dt,_=time_call(lambda:[policy_hash(p) for p in baseline]); ht.append(dt)
        dt,r=time_call(lambda:verify_policy_set(baseline,trusted,verify_ledger=True,ledger_path=LEDGER_FILE,signer=signer,require_signature=True,hrot=hrot)); vt.append(dt); assert r["all_compliant"]
        hashes=[policy_hash(p) for p in baseline]; dt,_=time_call(lambda:merkle_root(hashes)); merkle.append(dt)
    for _ in range(ATTACK_RUNS):
        tampered=copy.deepcopy(baseline); mutate(tampered,"POL-INT-001","decision","DENY")
        dt,r=time_call(lambda:verify_policy_set(tampered,trusted,signer=signer,require_signature=True,hrot=hrot)); lat.append(dt); assert r["tampered"]+r["forged"]>=1
    return {"runs":RUNS,"hash_times_ms":ht,"verification_times_ms":vt,"merkle_root_times_ms":merkle,"detection_latency_times_ms":lat,
            "hash_mean_ms":statistics.mean(ht),"hash_stdev_ms":statistics.stdev(ht),"verification_mean_ms":statistics.mean(vt),"verification_stdev_ms":statistics.stdev(vt),
            "merkle_root_mean_ms":statistics.mean(merkle),"detection_latency_mean_ms":statistics.mean(lat),"detection_latency_stdev_ms":statistics.stdev(lat),
            "hash_per_policy_ms":statistics.mean(ht)/len(baseline),"verification_per_policy_ms":statistics.mean(vt)/len(baseline)}

def confusion_matrix(baseline,ledger,signer,hrot):
    trusted=trusted_policy_map(ledger); obs=[]; tn=fp=tp=fn=0
    for i in range(1,BENIGN_RUNS+1):
        r=verify_policy_set(baseline,trusted,signer=signer,require_signature=True,hrot=hrot); pred=not r["all_compliant"]; tn+=not pred; fp+=pred; obs.append({"observation":i,"actual":"benign","predicted":"violation" if pred else "compliant"})
    attacks=[]
    for i in range(1,ATTACK_RUNS+1): attacks.append("modification" if i<=10 else "replay" if i<=20 else "forged_signature")
    for i,kind in enumerate(attacks,1):
        p=copy.deepcopy(baseline)
        if kind=="modification": mutate(p,"POL-INT-001","decision","DENY")
        elif kind=="replay":
            old=next(r["artifact_data"] for r in ledger if r["artifact_id"]=="POL-INT-001" and r["version"]==1); p[0]=copy.deepcopy(old)
        else: p[0]["signature"]="00"*64
        r=verify_policy_set(p,trusted,signer=signer,require_signature=True,hrot=hrot); pred=not r["all_compliant"]; tp+=pred; fn+=not pred; obs.append({"observation":BENIGN_RUNS+i,"actual":"violation","attack_type":kind,"predicted":"violation" if pred else "compliant"})
    total=tn+fp+tp+fn
    return {"TN":tn,"FP":fp,"FN":fn,"TP":tp,"accuracy":(tn+tp)/total,"precision":tp/(tp+fp) if tp+fp else 0,"recall":tp/(tp+fn) if tp+fn else 0,"false_positive_rate":fp/(fp+tn) if fp+tn else 0,"false_negative_rate":fn/(fn+tp) if fn+tp else 0,"observations":obs}

def scalability(signer,hrot):
    raw=[]; summary=[]; merkle_summary=[]
    for n in SCALABILITY_SIZES:
        policies=[synthetic_policy(i) for i in range(1,n+1)]; policies=[sign_policy(p,signer,hrot) for p in policies]; trusted={p["policy_id"]:p for p in policies}
        hashes=[policy_hash(p) for p in policies]
        for run in range(1,SCALABILITY_RUNS+1):
            ht,_=time_call(lambda:[policy_hash(p) for p in policies]); vt,_=time_call(lambda:verify_policy_set(policies,trusted,signer=signer,require_signature=True,hrot=hrot)); mt,_=time_call(lambda:merkle_root(hashes))
            raw.append({"policies":n,"run":run,"hash_ms":ht,"verification_ms":vt,"merkle_root_ms":mt,"hash_per_policy_ms":ht/n,"verification_per_policy_ms":vt/n})
        rows=[r for r in raw if r["policies"]==n]; hs=[r["hash_ms"] for r in rows]; vs=[r["verification_ms"] for r in rows]; ms=[r["merkle_root_ms"] for r in rows]
        summary.append({"policies":n,"hash_mean_ms":statistics.mean(hs),"hash_stdev_ms":statistics.stdev(hs),"verification_mean_ms":statistics.mean(vs),"verification_stdev_ms":statistics.stdev(vs),"merkle_root_mean_ms":statistics.mean(ms),"hash_per_policy_ms":statistics.mean(hs)/n,"verification_per_policy_ms":statistics.mean(vs)/n})
        # inclusion proof for one policy
        idx=min(3,n-1); pr=build_proof(hashes,idx); merkle_summary.append({"policies":n,"proof_length":len(pr),"proof_valid":verify_proof(hashes[idx],pr,merkle_root(hashes))})
    return raw,summary,merkle_summary

def extension_tests(baseline,signer,hrot):
    # HRoT attestation
    att=hrot.attest(canonical_bytes(baseline[0]))
    # Replicated local ledger quorum
    bc=LocalReplicatedLedger(3,2); bc.append({"policy_id":baseline[0]["policy_id"],"hash":policy_hash(baseline[0])}); bc_result=bc.verify_quorum()
    # Threshold authorization: 2 of 3 succeeds, 1 of 3 fails
    ta=ThresholdAuthority(3,2); msg=bytes.fromhex(policy_hash(baseline[0])); good=ta.verify(msg,ta.approvals(msg,[0,1])); bad=ta.verify(msg,ta.approvals(msg,[0]))
    # Merkle proof
    hashes=[policy_hash(p) for p in baseline]; root=merkle_root(hashes); proof=build_proof(hashes,0); mp=verify_proof(hashes[0],proof,root)
    return {"hrot":{**att,"status":hrot.implementation_status},"blockchain":bc_result,"threshold":{ "two_of_three":good,"one_of_three":bad },"merkle":{"root":root,"proof_valid":mp,"proof_length":len(proof)}}

def write_csv(path,rows,fields):
    with Path(path).open("w",newline="",encoding="utf-8") as f: csv.DictWriter(f,fieldnames=fields).writeheader(); csv.DictWriter(f,fieldnames=fields).writerows(rows)

def main():
    original_p=load_policies(); original_l=load_ledger(LEDGER_FILE)
    try:
        baseline,ledger,signer,hrot=fresh_baseline(); functional=functional_tests(baseline,ledger,signer,hrot); save_policies(copy.deepcopy(baseline))
        perf=performance_measurement(baseline,ledger,signer,hrot); cm=confusion_matrix(baseline,ledger,signer,hrot); save_policies(copy.deepcopy(baseline))
        raw,summary,merkle_summary=scalability(signer,hrot); ext=extension_tests(baseline,signer,hrot); chain=verify_chain(LEDGER_FILE,signer)
        x=np.array([r["policies"] for r in summary],float); hy=np.array([r["hash_mean_ms"] for r in summary]); vy=np.array([r["verification_mean_ms"] for r in summary]); my=np.array([r["merkle_root_mean_ms"] for r in summary])
        hm,hb=np.polyfit(x,hy,1); vm,vb=np.polyfit(x,vy,1); mm,mb=np.polyfit(x,my,1)
        r2=lambda y,m,b: float(1-((y-(m*x+b))**2).sum()/((y-y.mean())**2).sum())
        regression={"hash":{"slope_ms_per_policy":float(hm),"intercept_ms":float(hb),"r2":r2(hy,hm,hb)},"verification":{"slope_ms_per_policy":float(vm),"intercept_ms":float(vb),"r2":r2(vy,vm,vb)},"merkle_root":{"slope_ms_per_policy":float(mm),"intercept_ms":float(mb),"r2":r2(my,mm,mb)}}
        result={"package_version":"IB-NAC reproducibility package v4.0","core_implementation":["deterministic normalization","SHA-256 hash chain","Ed25519 policy provenance","monotonic version freshness","integrity verification","cryptographically verified rollback","Merkle inclusion proofs","2-of-3 threshold authorization"],"integration_extensions":["software HRoT adapter","replicated local-ledger adapter"],"functional":functional,"performance":perf,"confusion_matrix":{k:v for k,v in cm.items() if k!="observations"},"ledger_chain":chain,"scalability_summary":summary,"merkle_summary":merkle_summary,"scalability_regression":regression,"extensions":ext}
        save_json(RESULTS/"complete_results.json",result); save_json(RESULTS/"confusion_matrix.json",cm); save_json(RESULTS/"scalability_results.json",summary); save_json(RESULTS/"merkle_results.json",merkle_summary); save_json(RESULTS/"extensions_results.json",ext)
        perf_rows=[]
        for name,key in [("hash_computation","hash_times_ms"),("integrity_verification","verification_times_ms"),("detection_latency","detection_latency_times_ms"),("merkle_root","merkle_root_times_ms")]:
            for i,t in enumerate(perf[key],1): perf_rows.append({"measurement":name,"run":i,"time_ms":t})
        write_csv(RESULTS/"performance_raw.csv",perf_rows,["measurement","run","time_ms"])
        write_csv(RESULTS/"scalability_raw.csv",raw,["policies","run","hash_ms","verification_ms","merkle_root_ms","hash_per_policy_ms","verification_per_policy_ms"])
        write_csv(RESULTS/"confusion_matrix_observations.csv",cm["observations"], ["observation","actual","attack_type","predicted"])
        return result
    finally:
        save_policies(original_p); save_ledger(original_l,LEDGER_FILE)

if __name__=="__main__": print(json.dumps(main(),indent=2))
