# IB-NAC / IDCLM Reproducibility Package v5.0 — Scientific Evidence Upgrade

## Purpose

v5.0 preserves the executable v4.0 prototype while adding the experimental
controls needed to support a substantially stronger journal submission.

The upgrade is designed around five research questions:

- **RQ1:** Can IDCLM detect a broader set of enforcement-state integrity violations?
- **RQ2:** What does each cryptographic component contribute relative to simpler baselines?
- **RQ3:** What computational and recovery overhead does IDCLM introduce?
- **RQ4:** How does verification scale with policy-set size and policy complexity?
- **RQ5:** Does the software mechanism remain correct under benign changes that should
  be ignored by deterministic canonicalization?

## What was added

### 1. Baseline and ablation study

`measurements_v5.py` compares:

1. **none** — no cryptographic integrity protection;
2. **hash** — SHA-256 state comparison;
3. **signed** — hash + Ed25519 provenance verification;
4. **full_no_hrot** — hash + signature + freshness/version;
5. **full** — hash + signature + freshness + software HRoT, with ledger/completeness
   checks in the full attack evaluation.

Because the implemented canonical digest includes the policy version, stale
replay is already rejected by the hash comparison. The freshness check is
therefore a defense-in-depth control rather than an independently isolatable
source of replay detection in this implementation. The upgraded evaluation
does not pretend otherwise.

This directly addresses the reviewer question: *which IDCLM component provides
which security benefit?*

### 2. Expanded attack corpus

The evaluation includes 12 attack classes:

- decision flip;
- source-address change;
- destination change;
- protocol change;
- enforcement-command change;
- enforcement-point change;
- stale authorized replay;
- forged signature;
- version manipulation;
- HRoT-tag tampering;
- audit-ledger tampering;
- partial deployment.

The default run generates 100 randomized instances of each attack class
(1,200 attack observations) plus repeated benign canonicalization cases.

### 3. Benign robustness cases

The package checks that the verifier does not incorrectly flag:

- timestamp changes;
- key reordering;
- runtime/deployment metadata additions.

This is important because a security verifier should not produce artificial
false positives from irrelevant representation changes.

### 4. Repeated timing and statistical summaries

Timing outputs now include:

- n;
- mean;
- median;
- standard deviation;
- minimum/maximum;
- p95;
- p99;
- approximate 95% confidence interval.

Raw observations are retained in CSV files.

### 5. End-to-end software/emulation latency

The package measures:

`telemetry serialization → cryptographic verification → rollback → revalidation`

and reports the end-to-end software/emulation latency distribution.

This is **not** a physical network-device latency measurement.

### 6. Resource overhead

If `psutil` is installed, the package records process RSS deltas during
verification. If it is unavailable, the result explicitly reports that the
measurement was not available.

### 7. Larger and heterogeneous scalability

The default scalability range is:

`5, 10, 50, 100, 500, 1,000, 5,000, 10,000`

The CLI accepts arbitrary sizes, so larger workloads such as 50,000 or 100,000
policies can be run on a suitable machine.

Policy complexity changes from simple to complex at larger scales.

### 8. Sequential versus Merkle evaluation

For each scale, the package measures:

- SHA-256 hashing;
- sequential signed verification;
- Merkle-root construction;
- individual Merkle inclusion-proof verification;
- proof length.

The raw data allow the manuscript to avoid claiming a Merkle performance
advantage unless the measurements actually demonstrate one.

### 9. Optional high-fidelity network validation

`emulation/README.md` documents the recommended Mininet/Open vSwitch/controller
experiment. The package does not fabricate these results. They must be run in
an environment containing the actual emulator/controller and recorded as
emulation/testbed evidence.

## Installation

From the `IB-NAC` directory:

```bash
pip install -r requirements_v5.txt
```

## Run the upgraded suite

```bash
python measurements_v5.py
```

The default run performs:

- 100 attack instances per attack class;
- 100 end-to-end latency runs;
- 5 repetitions per scalability point;
- 5–10,000 policy scalability.

## Faster development run

```bash
python measurements_v5.py --attack-runs 10 --timing-runs 20 --scale-runs 2 --skip-large
```

## Larger journal-evidence run

For example:

```bash
python measurements_v5.py --attack-runs 250 --timing-runs 200 --scale-runs 10 --sizes 5,10,50,100,500,1000,5000,10000,50000,100000
```

A 100,000-policy run may require substantial CPU/RAM and should be executed on
the actual reporting machine. Do not transfer results between machines without
recording the hardware/software environment.

## Generate figures

After running the experiments:

```bash
python plot_results_v5.py
```

The script reads the raw CSVs rather than generating synthetic values.

## Outputs

### Main results

- `results/complete_results_v5.json`
- `results/ablation_results.json`
- `results/functional_recovery_v5.json`
- `results/e2e_latency_results.json`
- `results/resource_overhead.json`
- `results/scalability_results_v5.json`

### Raw observations

- `results/ablation_observations.csv`
- `results/e2e_latency_raw.csv`
- `results/scalability_raw_v5.csv`

### Figures

If matplotlib is installed:

- `results/figure_scalability_v5.png`
- `results/figure_e2e_latency_v5.png`

## Recommended manuscript mapping

| Manuscript section | v5 evidence |
|---|---|
| Security effectiveness | `ablation_results.json` |
| Baseline comparison | `ablation_results.json` |
| Attack-class analysis | `ablation_results.json` + raw observations |
| False-positive robustness | benign cases in `ablation_results.json` |
| Recovery | `functional_recovery_v5.json` |
| End-to-end latency | `e2e_latency_results.json` |
| Resource overhead | `resource_overhead.json` |
| Scalability | `scalability_results_v5.json` |
| Merkle comparison | `scalability_results_v5.json` |
| Figures | `plot_results_v5.py` outputs |

## Important interpretation rules

1. Do not describe the 100% detection result, if obtained, as general
   "accuracy." State the number and diversity of tested observations.
2. Do not describe software/emulation latency as end-to-end physical-network
   latency.
3. Do not claim that a baseline "cannot" provide a capability merely because
   it is not implemented in this package; describe the exact baseline tested.
4. Do not claim production TPM/HSM security from `extensions/hrot.py`.
5. Do not claim blockchain consensus from `extensions/blockchain.py`.
6. Do not describe the threshold module as FROST or another distributed
   threshold-signature protocol.
7. Do not claim Merkle performance superiority unless the raw measurements
   establish it.
8. Record the hardware, operating system, Python version, package versions and
   workload parameters with every journal submission run.

## What this package does not yet establish

The v5 upgrade substantially strengthens software-level scientific evidence,
but it does **not** itself establish:

- physical network-device performance;
- production SDN-controller overhead;
- real telemetry transport behavior;
- TPM/HSM hardware-rooted trust;
- production distributed consensus;
- protection against compromise of the trusted signing key/baseline;
- semantic correctness of an upstream intent compiler.

Those require the optional higher-fidelity experiments described in
`emulation/README.md` and, where appropriate, real hardware.

## Reproducibility principle

All numerical manuscript claims must be regenerated from raw package outputs
on the machine used for the final experimental run. Do not manually edit
results to match an earlier manuscript draft.

## V6 high-fidelity validation
See `testbed/README_V6_HIGH_FIDELITY.md`. V6 adds CML/SSH and Mininet/OVS adapters and a revised freshness model. These are experimental drivers only; they do not contain fabricated high-fidelity results.
