"""Generate manuscript-ready plots from v5 raw results.

Usage:
    python plot_results_v5.py

Requires matplotlib. The script does not fabricate data; it reads the raw CSVs
produced by measurements_v5.py.
"""
from pathlib import Path
import csv, statistics

try:
    import matplotlib.pyplot as plt
except ImportError:
    raise SystemExit("Install matplotlib to generate figures.")

BASE=Path(__file__).resolve().parent
R=BASE/"results"

def read_csv(name):
    with open(R/name,newline="",encoding="utf8") as f: return list(csv.DictReader(f))

scale=read_csv("scalability_raw_v5.csv")
if scale:
    groups={}
    for row in scale:
        n=int(row["policies"])
        groups.setdefault(n,{"seq":[],"hash":[],"merkle":[]})
        groups[n]["seq"].append(float(row["sequential_verification_ms"]))
        groups[n]["hash"].append(float(row["hash_ms"]))
        groups[n]["merkle"].append(float(row["merkle_root_ms"]))
    xs=sorted(groups)
    plt.figure()
    plt.plot(xs,[statistics.mean(groups[x]["seq"]) for x in xs],marker="o",label="Sequential verification")
    plt.plot(xs,[statistics.mean(groups[x]["merkle"]) for x in xs],marker="o",label="Merkle root construction")
    plt.xscale("log"); plt.yscale("log")
    plt.xlabel("Policy-set size"); plt.ylabel("Time (ms)")
    plt.title("IDCLM scalability")
    plt.legend(); plt.tight_layout()
    plt.savefig(R/"figure_scalability_v5.png",dpi=300); plt.close()

e2e=read_csv("e2e_latency_raw.csv")
if e2e:
    plt.figure()
    vals=[float(x["end_to_end_ms"]) for x in e2e]
    plt.hist(vals,bins=20)
    plt.xlabel("End-to-end software/emulation latency (ms)")
    plt.ylabel("Frequency")
    plt.title("IDCLM detection-to-recovery latency distribution")
    plt.tight_layout()
    plt.savefig(R/"figure_e2e_latency_v5.png",dpi=300); plt.close()

print("Figures written to results/.")
