"""Cryptographic identity, signatures and freshness support."""
from __future__ import annotations
import base64
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

class Signer:
    def __init__(self, private_key=None):
        self._key=private_key or Ed25519PrivateKey.generate()
    @property
    def public_key(self):
        return base64.b64encode(self._key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)).decode()
    def sign(self,data:bytes)->str:
        return base64.b64encode(self._key.sign(data)).decode()
    @staticmethod
    def verify(data:bytes,signature:str,public_key_b64:str):
        if not signature or not public_key_b64: raise ValueError("missing signature/key")
        key=Ed25519PublicKey.from_public_bytes(base64.b64decode(public_key_b64))
        key.verify(base64.b64decode(signature),data)
