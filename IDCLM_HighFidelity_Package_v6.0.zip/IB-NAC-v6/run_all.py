from measurements import main
import json
r=main()
print(json.dumps({'package_version':r['package_version'],'confusion_matrix':r['confusion_matrix'],'performance':r['performance'],'one_thousand_policy':r['scalability_summary'][-1],'extensions':r['extensions']},indent=2))
