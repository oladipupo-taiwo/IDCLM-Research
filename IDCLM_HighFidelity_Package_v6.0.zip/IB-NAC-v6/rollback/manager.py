"""Cryptographically verified rollback manager."""
from __future__ import annotations
import copy,json
from pathlib import Path
from ledger import append
from normalizer import canonical_bytes
from verifier import verify_policy
class RollbackManager:
    def __init__(self,policy_file="compiled_policies.json",ledger_file="audit_ledger.json",signer=None,hrot=None):
        self.policy_file=Path(policy_file); self.ledger_file=Path(ledger_file); self.signer=signer; self.hrot=hrot
    def load_policies(self): return json.loads(self.policy_file.read_text(encoding="utf-8"))
    def save_policies(self,p): self.policy_file.write_text(json.dumps(p,indent=2,ensure_ascii=False),encoding="utf-8")
    def rollback_policy(self,policy_id,trusted_policy,version=None):
        policies=self.load_policies(); found=False
        target=copy.deepcopy(trusted_policy)
        target["version"]=int(version if version is not None else trusted_policy.get("version",1))
        for p in policies:
            if p.get("policy_id")==policy_id: p.clear(); p.update(target); found=True; break
        if not found: raise KeyError(policy_id)
        self.save_policies(policies); restored=next(p for p in policies if p.get("policy_id")==policy_id)
        result=verify_policy(restored,target,signer=self.signer,require_signature=False,hrot=self.hrot)
        success=result["status"]=="COMPLIANT"
        append("POLICY_ROLLBACK",policy_id,{"policy_id":policy_id,"restored_version":target["version"],"success":success,"policy_hash":result["current_hash"]},self.ledger_file,"Verified rollback to trusted state",self.signer,target["version"],hrot_tag=self.hrot.seal(canonical_bytes(target)) if self.hrot else None)
        return {"policy_id":policy_id,"success":success,"verification":result}
